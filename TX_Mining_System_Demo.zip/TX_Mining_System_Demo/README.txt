TX MINING SYSTEM — FRONT-END DEMO

Open index.html in a browser. Keep tx_logo.jpg in the same folder so the logo appears.

Included:
- TX logo supplied by you
- Start Mining button
- 24-hour simulated mining session
- Demo rate 0.250 TX/hour
- Live timer, progress bar, demo balance and total earned
- Local browser storage (this demo's balance is not server-secured)
- Wallet / Withdraw / Invite placeholder actions

This is only the mining UI/prototype. Next step can be connecting this design and mining logic to the Python Telegram bot, where balances are stored server-side.
It does not perform real blockchain mining or transfer cryptocurrency.
